from flask import Flask, request, render_template, redirect, url_for
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import load_model
import os
import joblib
import numpy as np

app = Flask(__name__)

# Direktori konfigurasi
UPLOAD_FOLDER = 'uploads'
MODEL_SVM_PATH = 'model_svm.pkl'  # SVM model
MODEL_CNN_PATH = 'pepaya_diseases.keras'  # DenseNet CNN feature extractor

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Memuat model SVM dan CNN
svm_classifier = joblib.load(MODEL_SVM_PATH)
cnn_model = load_model(MODEL_CNN_PATH)

# Menghilangkan layer klasifikasi terakhir dari CNN
from tensorflow.keras.models import Model
feature_extractor = Model(inputs=cnn_model.input, outputs=cnn_model.get_layer(index=-2).output)

# Kelas prediksi
CLASS_NAMES = ['Antraknosa', 'Blackspot', 'Keriting-Daun']

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Simpan file upload
        file = request.files['file']
        if file and file.filename:
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filepath)

            # Proses gambar
            img = load_img(filepath, target_size=(224, 224))  # Resize sesuai input DenseNet
            img_array = img_to_array(img) / 255.0  # Normalisasi gambar
            img_array = np.expand_dims(img_array, axis=0)  # Tambahkan batch dimension

            # Ekstrak fitur menggunakan DenseNet
            features = feature_extractor.predict(img_array)  # Output fitur CNN
            features_flatten = features.flatten().reshape(1, -1)  # Flatten menjadi 1D

            # Prediksi menggunakan model SVM
            try:
                prediction_proba = svm_classifier.predict_proba(features_flatten)  # Probabilitas prediksi
                prediction_index = np.argmax(prediction_proba)  # Index prediksi kelas tertinggi
                predicted_class = CLASS_NAMES[prediction_index]
                confidence = round(100 * prediction_proba[0][prediction_index], 2)  # Hitung confidence
            except AttributeError:
                # Jika model tidak mendukung predict_proba
                prediction = svm_classifier.predict(features_flatten)
                predicted_class = CLASS_NAMES[prediction[0]]
                confidence = "N/A"

            # Return hasil prediksi
            return render_template('result.html',
                                   filename=file.filename,
                                   predicted_class=predicted_class,
                                   confidence=confidence)

    return render_template('index.html')

# Route untuk menampilkan gambar yang diupload
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return redirect(url_for('static', filename=f'uploads/{filename}'))

if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)
